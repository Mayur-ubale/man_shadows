<?php
/**
 * Plugin Name: Men's Shadows UPI QR Payment
 * Description: Adds an online-only UPI QR payment method to WooCommerce for Men's Shadows.
 * Version: 1.0.0
 * Author: Men's Shadows
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_filter( 'woocommerce_payment_gateways', function( $gateways ) {
    $gateways[] = 'WC_Gateway_Mens_Shadows_UPI_QR';
    return $gateways;
} );

add_action( 'plugins_loaded', function() {
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

    class WC_Gateway_Mens_Shadows_UPI_QR extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'mens_shadows_upi_qr';
            $this->icon               = '';
            $this->has_fields         = true;
            $this->method_title       = "Men's Shadows UPI QR";
            $this->method_description = 'Manual UPI QR payment. The order stays on-hold until payment is verified.';
            $this->title              = "UPI QR — Online Payment Only";
            $this->description        = "Scan the QR code, complete payment, and enter your UTR/reference number.";

            $this->init_form_fields();
            $this->init_settings();

            $this->title       = $this->get_option( 'title', $this->title );
            $this->description = $this->get_option( 'description', $this->description );
            $this->qr_url      = $this->get_option( 'qr_url', '' );
            $this->upi_id      = $this->get_option( 'upi_id', '' );

            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
        }

        public function init_form_fields() {
            $this->form_fields = [
                'enabled' => [
                    'title' => 'Enable/Disable',
                    'type' => 'checkbox',
                    'label' => 'Enable UPI QR payment',
                    'default' => 'yes',
                ],
                'title' => [
                    'title' => 'Title',
                    'type' => 'text',
                    'default' => 'UPI QR — Online Payment Only',
                ],
                'description' => [
                    'title' => 'Description',
                    'type' => 'textarea',
                    'default' => 'Scan the QR code, complete payment, and enter your UTR/reference number.',
                ],
                'qr_url' => [
                    'title' => 'QR Image URL',
                    'type' => 'text',
                    'description' => 'Upload the supplied QR image to Media Library and paste its URL here.',
                    'default' => '',
                ],
                'upi_id' => [
                    'title' => 'UPI ID',
                    'type' => 'text',
                    'description' => 'Optional UPI ID shown below the QR.',
                    'default' => '',
                ],
            ];
        }

        public function payment_fields() {
            echo wpautop( wp_kses_post( $this->description ) );

            if ( ! empty( $this->qr_url ) ) {
                echo '<div style="text-align:center;margin:15px 0">';
                echo '<img src="' . esc_url( $this->qr_url ) . '" alt="UPI QR" style="width:220px;height:220px;object-fit:contain">';
                if ( ! empty( $this->upi_id ) ) {
                    echo '<p><strong>UPI ID:</strong> ' . esc_html( $this->upi_id ) . '</p>';
                }
                echo '</div>';
            }

            woocommerce_form_field( 'mens_shadows_utr', [
                'type' => 'text',
                'label' => 'UPI UTR / Transaction Reference *',
                'required' => true,
                'placeholder' => 'Enter your payment reference',
            ], '' );

            echo '<p style="font-size:12px;color:#777">Your order will remain on-hold until the payment is manually verified.</p>';
        }

        public function validate_fields() {
            $utr = isset( $_POST['mens_shadows_utr'] ) ? sanitize_text_field( wp_unslash( $_POST['mens_shadows_utr'] ) ) : '';
            if ( empty( $utr ) ) {
                wc_add_notice( 'Please enter your UPI UTR / transaction reference.', 'error' );
                return false;
            }
            return true;
        }

        public function process_payment( $order_id ) {
            $order = wc_get_order( $order_id );
            $utr = isset( $_POST['mens_shadows_utr'] ) ? sanitize_text_field( wp_unslash( $_POST['mens_shadows_utr'] ) ) : '';

            $order->update_meta_data( '_mens_shadows_utr', $utr );
            $order->add_order_note( 'UPI QR payment reference submitted: ' . $utr . '. Payment requires manual verification.' );

            // Do not mark as paid automatically. Merchant verifies the payment first.
            $order->update_status( 'on-hold', 'UPI QR payment submitted; waiting for manual verification.' );
            $order->save();

            return [
                'result'   => 'success',
                'redirect' => $this->get_return_url( $order ),
            ];
        }
    }
} );
