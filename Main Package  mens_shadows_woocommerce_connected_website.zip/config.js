/*
  MEN'S SHADOWS WEBSITE CONFIG
  ----------------------------
  Put your real WooCommerce website URL and WooCommerce product IDs here.

  Example:
  const STORE_CONFIG = {
    woocommerceUrl: "https://yourdomain.com",
    products: {
      pack1: 123,
      pack2: 124,
      pack3: 125
    }
  };

  The website uses normal WooCommerce add-to-cart URLs:
  /?add-to-cart=PRODUCT_ID&quantity=1

  If the IDs are left as 0, the site will show the QR/manual-order
  information instead of sending an invalid WooCommerce cart request.
*/
const STORE_CONFIG = {
  woocommerceUrl: "https://YOUR-WOOCOMMERCE-DOMAIN.com",
  products: {
    pack1: 0,
    pack2: 0,
    pack3: 0
  },
  checkoutPath: "/checkout/"
};
