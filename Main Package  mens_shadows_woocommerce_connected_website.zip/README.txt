MEN'S SHADOWS — WOOCOMMERCE READY PACKAGE
============================================

WHAT IS INCLUDED
----------------
1. index.html
   Premium product store with:
   - Single-product hero
   - Pack of 1 — ₹199
   - Pack of 2 — ₹359
   - Pack of 3 — ₹449
   - Supplied pack images
   - Customer-care details
   - Instagram link

2. order.html
   - Pack selector
   - Customer details
   - Online-payment-only section
   - Supplied QR code
   - WooCommerce redirect logic
   - Mobile responsive checkout UI

3. config.js
   Put your WooCommerce domain and PRODUCT IDs here.

4. woocommerce-upi-qr-gateway.php
   Optional WooCommerce plugin that adds a UPI QR payment gateway.
   It asks for a UTR/reference number and keeps the order ON-HOLD until
   you manually verify payment. It does NOT falsely mark QR payments as paid.

5. assets/
   - product.jpg
   - pack-1.jpg
   - pack-2.jpg
   - pack-3.png
   - payment-qr.jpg

HOW TO CONNECT TO YOUR WOOCOMMERCE STORE
----------------------------------------
STEP 1 — Create 3 WooCommerce products
Create:
- Men's Shadows — Pack of 1 — ₹199
- Men's Shadows — Pack of 2 — ₹359
- Men's Shadows — Pack of 3 — ₹449

STEP 2 — Get their product IDs
In WordPress:
WooCommerce → Products
Open each product and note its Product ID.

STEP 3 — Edit config.js
Replace:
https://YOUR-WOOCOMMERCE-DOMAIN.com

with your actual WooCommerce website URL.

Then replace:
pack1: 0
pack2: 0
pack3: 0

with the three product IDs.

Example:
const STORE_CONFIG = {
  woocommerceUrl: "https://example.com",
  products: {
    pack1: 123,
    pack2: 124,
    pack3: 125
  },
  checkoutPath: "/checkout/"
};

STEP 4 — Payment
The supplied QR image is included on the order page.

For real WooCommerce checkout:
- Upload payment-qr.jpg to WordPress Media Library.
- Install/activate woocommerce-upi-qr-gateway.php as a plugin.
- Go to WooCommerce → Settings → Payments.
- Enable "UPI QR — Online Payment Only".
- Paste the Media Library QR URL.
- Optionally add your UPI ID.
- Test with a small real/test transaction according to your payment provider's rules.

IMPORTANT
---------
The static HTML page cannot securely create WooCommerce orders by itself across
different domains. The normal production setup is to host the storefront on the
same domain as WordPress/WooCommerce or use WooCommerce's APIs.

WooCommerce supports payment gateways and its checkout API can create orders and
handle payment methods. See official docs:
https://woocommerce.com/documentation/payments/
https://developer.woocommerce.com/docs/apis/store-api/resources-endpoints/checkout/

MEESHO
------
This version focuses on WooCommerce as requested. If you also want a Meesho
button, add your exact Meesho product listing URL separately. Do not use a
generic Meesho URL as the final purchase link.

ONLINE PAYMENT ONLY
-------------------
No Cash on Delivery option is included in the website UI.

CONTACT DETAILS USED
--------------------
Phone: +91 94204 90945
Email: mensshadows00@gmail.com
Instagram: https://www.instagram.com/shadowmen.in?stkn=YnU2MXEwa3FmNDJ5

These details came from the information supplied with this request.
